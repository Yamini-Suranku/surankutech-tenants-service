"""
Tenant Service Client for Organization Access Control
Centralized client for interacting with the tenant service APIs
"""

import httpx
import logging
from typing import Dict, Any, List, Optional
import os

logger = logging.getLogger(__name__)

class TenantServiceClient:
    """Centralized client for tenant service operations"""

    def __init__(self):
        self.base_url = os.getenv(
            "TENANT_SERVICE_URL",
            "http://tenants-service.tenant-services.svc.cluster.local"
        )
        self.timeout = float(os.getenv("TENANT_SERVICE_TIMEOUT", "10.0"))

    async def resolve_organization_by_hostname(self, hostname: str) -> Dict[str, Any]:
        """
        Resolve organization context by hostname for DNS-based routing

        Args:
            hostname: Full hostname (e.g., "palls.local.suranku")

        Returns:
            Organization context with app access details
        """
        try:
            url = f"{self.base_url}/api/organizations/by-hostname/{hostname}"

            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(url)

                if response.status_code == 404:
                    return {
                        "found": False,
                        "error": f"Organization not found for hostname '{hostname}'"
                    }
                elif response.status_code != 200:
                    logger.error(f"Failed to resolve org by hostname: {response.status_code} - {response.text}")
                    return {
                        "found": False,
                        "error": f"Service error: {response.status_code}"
                    }

                org_data = response.json()
                org_data["found"] = True
                return org_data

        except Exception as e:
            logger.error(f"Error resolving organization by hostname '{hostname}': {e}")
            return {
                "found": False,
                "error": f"Communication error: {str(e)}"
            }

    async def validate_organization_access(
        self,
        org_slug: str,
        user_keycloak_id: str,
        app_name: Optional[str] = None,
        required_role: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Validate if user has access to organization and optionally specific app/role

        Args:
            org_slug: Organization slug (e.g., "palls")
            user_keycloak_id: User's Keycloak UUID
            app_name: Optional app name to check (e.g., "darkhole")
            required_role: Optional role to validate (e.g., "admin")

        Returns:
            Access validation result with user's roles
        """
        try:
            url = f"{self.base_url}/api/organizations/{org_slug}/validate-access"
            params = {}
            if app_name:
                params["app_name"] = app_name
            if required_role:
                params["required_role"] = required_role

            headers = {
                "X-User-Keycloak-Id": user_keycloak_id,
                "Content-Type": "application/json"
            }

            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(url, params=params, headers=headers)

                if response.status_code != 200:
                    logger.error(f"Access validation failed: {response.status_code} - {response.text}")
                    return {
                        "has_access": False,
                        "reason": f"Service error: {response.status_code}"
                    }

                return response.json()

        except Exception as e:
            logger.error(f"Error validating organization access: {e}")
            return {
                "has_access": False,
                "reason": f"Communication error: {str(e)}"
            }

    async def get_user_organization_roles(
        self,
        org_slug: str,
        user_keycloak_id: str
    ) -> Dict[str, Any]:
        """
        Get user's app-specific roles within an organization

        Args:
            org_slug: Organization slug (e.g., "palls")
            user_keycloak_id: User's Keycloak UUID

        Returns:
            User's roles for each app in the organization
        """
        try:
            url = f"{self.base_url}/api/organizations/{org_slug}/users/{user_keycloak_id}/roles"

            headers = {
                "X-User-Keycloak-Id": user_keycloak_id,
                "Content-Type": "application/json"
            }

            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(url, headers=headers)

                if response.status_code == 404:
                    return {
                        "found": False,
                        "app_roles": {}
                    }
                elif response.status_code != 200:
                    logger.error(f"Failed to get user org roles: {response.status_code} - {response.text}")
                    return {
                        "found": False,
                        "app_roles": {},
                        "error": f"Service error: {response.status_code}"
                    }

                data = response.json()
                data["found"] = True
                return data

        except Exception as e:
            logger.error(f"Error getting user organization roles: {e}")
            return {
                "found": False,
                "app_roles": {},
                "error": f"Communication error: {str(e)}"
            }

    async def get_user_org_memberships(
        self,
        user_keycloak_id: str
    ) -> List[Dict[str, Any]]:
        """
        Get all organization memberships for a user

        Args:
            user_keycloak_id: User's Keycloak UUID

        Returns:
            List of organization memberships with app roles
        """
        try:
            url = f"{self.base_url}/api/organizations/memberships/me"

            headers = {
                "X-User-Keycloak-Id": user_keycloak_id,
                "Content-Type": "application/json"
            }

            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(url, headers=headers)

                if response.status_code != 200:
                    logger.error(f"Failed to get user memberships: {response.status_code} - {response.text}")
                    return []

                return response.json()

        except Exception as e:
            logger.error(f"Error getting user org memberships: {e}")
            return []

    async def get_enhanced_token_data(
        self,
        user_keycloak_id: str
    ) -> Dict[str, Any]:
        """
        Get enhanced user data with org memberships for JWT token enhancement

        Args:
            user_keycloak_id: User's Keycloak UUID

        Returns:
            Enhanced token data including org memberships and app roles
        """
        try:
            url = f"{self.base_url}/api/token-enhancement/user-enhanced-data"
            params = {"user_id": user_keycloak_id}

            async with httpx.AsyncClient(timeout=self.timeout) as client:
                response = await client.get(url, params=params)

                if response.status_code != 200:
                    logger.error(f"Failed to get enhanced token data: {response.status_code} - {response.text}")
                    return {"org_memberships": [], "app_roles": {}}

                return response.json()

        except Exception as e:
            logger.error(f"Error getting enhanced token data: {e}")
            return {"org_memberships": [], "app_roles": {}}

    def extract_subdomain_from_hostname(self, hostname: str) -> Optional[str]:
        """
        Extract organization subdomain from hostname

        Args:
            hostname: Full hostname (e.g., "palls.local.suranku")

        Returns:
            Organization subdomain (e.g., "palls") or None
        """
        import re

        # Pattern to match org.domain.tld or org.local.domain.tld
        patterns = [
            r'^([a-zA-Z0-9-]+)\.local\.suranku$',  # palls.local.suranku
            r'^([a-zA-Z0-9-]+)\.darkhole\.suranku\.net$',  # palls.darkhole.suranku.net
            r'^([a-zA-Z0-9-]+)\.darkfolio\.suranku\.net$',  # palls.darkfolio.suranku.net
            r'^([a-zA-Z0-9-]+)\.suranku\.net$',  # palls.suranku.net
        ]

        for pattern in patterns:
            match = re.match(pattern, hostname)
            if match:
                org_slug = match.group(1)
                # Skip system subdomains
                if org_slug not in ['shared', 'api', 'www', 'admin', 'status', 'auth', 'keycloak']:
                    logger.info(f"📍 Extracted org slug '{org_slug}' from hostname '{hostname}'")
                    return org_slug

        logger.warning(f"⚠️ Could not extract org slug from hostname: {hostname}")
        return None

# Global instance for shared use
tenant_service_client = TenantServiceClient()