"""
Updated Authentication Utilities using Tenant Service
Replaces direct database access with tenant service API calls
"""

import logging
from typing import Dict, Any, Optional
from fastapi import HTTPException, status

from .tenant_service_client import tenant_service_client
from .auth import TokenData, extract_subdomain_from_hostname

logger = logging.getLogger(__name__)

async def require_org_app_role_async(
    token_data: TokenData,
    hostname: str,
    app_client: str,
    required_role: str
) -> bool:
    """
    Async organization-aware role check using tenant service.

    Args:
        token_data: Validated JWT token data
        hostname: Request hostname (e.g., "palls.local.suranku")
        app_client: App client name (e.g., "darkhole", "darkfolio")
        required_role: Required role (e.g., "admin", "user")

    Returns:
        True if user has the required role for this org's app

    Raises:
        HTTPException: If user has no access to the organization or hostname is invalid
    """
    logger.info(f"🔐 ORG ROLE CHECK: hostname={hostname}, app={app_client}, role={required_role}")
    logger.info(f"👤 User: {getattr(token_data, 'email', 'unknown')}")

    # Extract organization slug from hostname
    org_slug = tenant_service_client.extract_subdomain_from_hostname(hostname)
    if not org_slug:
        logger.error(f"❌ No valid organization subdomain in hostname '{hostname}'")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid hostname: No organization subdomain found in '{hostname}'"
        )

    logger.info(f"🏢 Target organization: {org_slug}")

    # Check org memberships in token first (faster)
    org_memberships = getattr(token_data, 'org_memberships', [])
    if org_memberships:
        logger.info(f"📋 User org memberships: {[m.get('org_slug') for m in org_memberships]}")

        for org_membership in org_memberships:
            if org_membership.get('org_slug') == org_slug:
                org_app_roles = org_membership.get('app_roles', {}).get(app_client, [])
                logger.info(f"🎯 User roles in {org_slug}.{app_client}: {org_app_roles}")

                if required_role in org_app_roles:
                    logger.info(f"✅ Access granted: {required_role} found in org-specific roles")
                    return True
                else:
                    logger.warning(f"❌ Access denied: {required_role} not in org-specific roles {org_app_roles}")
                    raise HTTPException(
                        status_code=status.HTTP_403_FORBIDDEN,
                        detail=f"Access denied: Insufficient privileges for {app_client} in organization '{org_slug}'"
                    )

        logger.warning(f"❌ Access denied: User not member of organization '{org_slug}'")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Access denied: No membership in organization '{org_slug}'"
        )

    # Fallback to tenant service API if no org memberships in token
    logger.info("🔄 No org_memberships in token, checking with tenant service")
    user_keycloak_id = getattr(token_data, 'sub', None)
    if not user_keycloak_id:
        logger.error("❌ No user ID in token")
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied: Invalid token")

    # Call tenant service to validate access
    access_result = await tenant_service_client.validate_organization_access(
        org_slug=org_slug,
        user_keycloak_id=user_keycloak_id,
        app_name=app_client,
        required_role=required_role
    )

    if not access_result.get("has_access", False):
        reason = access_result.get("reason", "Access denied")
        logger.warning(f"❌ Tenant service denied access: {reason}")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Access denied: {reason}"
        )

    logger.info(f"✅ Tenant service granted access for {user_keycloak_id} to {org_slug}.{app_client} with role {required_role}")
    return True

async def require_org_admin_access_async(
    token_data: TokenData,
    hostname: str,
    app_client: str = "darkhole"
) -> bool:
    """Check if user has organization admin access for the specific org"""
    return await require_org_app_role_async(token_data, hostname, app_client, "admin")

async def require_org_model_approval_access_async(
    token_data: TokenData,
    hostname: str,
    app_client: str = "darkhole"
) -> bool:
    """Check if user has model approval access in the specific organization"""
    # Try different admin-level roles
    admin_roles = ["admin", "administrator", "evaluator", "stuart"]

    for role in admin_roles:
        try:
            return await require_org_app_role_async(token_data, hostname, app_client, role)
        except HTTPException as e:
            if "Insufficient privileges" in str(e.detail):
                continue  # Try next role
            else:
                raise  # Re-raise if it's not a role issue

    # If none of the roles worked, raise the last exception
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail=f"Access denied: User lacks admin privileges for {app_client} in this organization"
    )

async def get_user_org_context_async(
    token_data: TokenData,
    hostname: str
) -> Dict[str, Any]:
    """
    Get user's organization context for a given hostname

    Returns:
        Organization context with user's roles
    """
    user_keycloak_id = getattr(token_data, 'sub', None)
    if not user_keycloak_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Invalid token")

    # Extract organization slug from hostname
    org_slug = tenant_service_client.extract_subdomain_from_hostname(hostname)
    if not org_slug:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid hostname: No organization subdomain found in '{hostname}'"
        )

    # Get user's roles in this organization
    roles_result = await tenant_service_client.get_user_organization_roles(
        org_slug=org_slug,
        user_keycloak_id=user_keycloak_id
    )

    if not roles_result.get("found", False):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Access denied: No access to organization '{org_slug}'"
        )

    return {
        "org_slug": org_slug,
        "organization": roles_result.get("organization", {}),
        "app_roles": roles_result.get("app_roles", {})
    }

async def validate_org_access_for_hostname_async(
    hostname: str
) -> Dict[str, Any]:
    """
    Validate that an organization exists for the given hostname

    Returns:
        Organization context if found
    """
    org_result = await tenant_service_client.resolve_organization_by_hostname(hostname)

    if not org_result.get("found", False):
        error = org_result.get("error", f"Organization not found for hostname '{hostname}'")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=error
        )

    return org_result

# Legacy sync wrappers for backward compatibility
# These should be gradually replaced with async versions

def require_org_app_role(token_data: TokenData, hostname: str, app_client: str, required_role: str) -> bool:
    """
    DEPRECATED: Synchronous wrapper for backward compatibility.
    Use require_org_app_role_async instead.
    """
    import asyncio
    try:
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(
            require_org_app_role_async(token_data, hostname, app_client, required_role)
        )
    except RuntimeError:
        # No event loop running
        return asyncio.run(
            require_org_app_role_async(token_data, hostname, app_client, required_role)
        )

def require_org_admin_access(token_data: TokenData, hostname: str, app_client: str = "darkhole") -> bool:
    """DEPRECATED: Use require_org_admin_access_async instead"""
    return require_org_app_role(token_data, hostname, app_client, "admin")

def require_org_model_approval_access(token_data: TokenData, hostname: str, app_client: str = "darkhole") -> bool:
    """DEPRECATED: Use require_org_model_approval_access_async instead"""
    import asyncio
    try:
        loop = asyncio.get_event_loop()
        return loop.run_until_complete(
            require_org_model_approval_access_async(token_data, hostname, app_client)
        )
    except RuntimeError:
        return asyncio.run(
            require_org_model_approval_access_async(token_data, hostname, app_client)
        )