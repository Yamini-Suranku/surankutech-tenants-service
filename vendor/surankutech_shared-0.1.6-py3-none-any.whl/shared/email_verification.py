"""
Email Verification Service
Shared implementation used by tenants and platform services.
"""

import hashlib
import logging
import os
import secrets
import smtplib
from datetime import datetime, timedelta
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Dict, Optional

from sqlalchemy.orm import Session

from shared.database import get_db
from shared.email_service import BaseEmailService
from shared.models import TenantAppAccess, User, UserStatus, UserTenant

logger = logging.getLogger(__name__)


class EmailVerificationService(BaseEmailService):
    """Service for handling email verification in user registration"""

    def __init__(self):
        super().__init__()
        self.verification_expiry_hours = 24
        self.max_resend_attempts = 3
        self.resend_cooldown_minutes = 5

    async def send_verification_email(
        self,
        db: Session,
        user: User,
        resend: bool = False
    ) -> Dict[str, str]:
        """Send verification email or log fallback for development."""
        try:
            if user.is_email_verified:
                return {"status": "already_verified", "message": "Email is already verified"}

            if resend and user.email_verification_sent_at:
                cooldown_time = user.email_verification_sent_at + timedelta(minutes=self.resend_cooldown_minutes)
                if datetime.utcnow() < cooldown_time:
                    remaining_minutes = (cooldown_time - datetime.utcnow()).total_seconds() / 60
                    return {
                        "status": "cooldown_active",
                        "message": f"Please wait {int(remaining_minutes)} more minutes before requesting another verification email",
                    }

            verification_token = self._generate_verification_token(user.email)
            expires_at = datetime.utcnow() + timedelta(hours=self.verification_expiry_hours)

            user.email_verification_token = verification_token
            user.email_verification_sent_at = datetime.utcnow()
            user.email_verification_expires_at = expires_at
            db.commit()

            async def auto_verify_fallback():
                await self._auto_verify_development_user(user.email, verification_token)

            subject, html_body = self._build_email_content(user=user, token=verification_token, expires_at=expires_at)
            development_info = {
                "Verification email sent to": user.email,
                "User name": f"{user.first_name} {user.last_name}".strip() or "User",
                "Token expires": expires_at.isoformat(),
                "Verification URL": self._build_action_url(email=user.email, token=verification_token),
            }

            result = await self._send_email(
                to_email=user.email,
                subject=subject,
                html_body=html_body,
                development_fallback_action=auto_verify_fallback,
                development_info=development_info,
                email_type="verification",
                db=db,
                context_ids={"user_id": user.id},
            )

            return {
                "status": "sent",
                "message": "Verification email sent" if result["status"] == "sent" else "Verification email logged (development)",
                "expires_at": expires_at.isoformat(),
                "token": verification_token,
            }

        except Exception as exc:  # pragma: no cover - defensive
            logger.error(f"Email verification sending error: {exc}")
            db.rollback()
            raise Exception(f"Failed to send verification email: {exc}") from exc

    async def verify_email(self, db: Session, email: str, token: str) -> Dict[str, str]:
        """Verify email token and activate account."""
        try:
            user = db.query(User).filter(User.email == email, User.email_verification_token == token).first()
            if not user:
                return {"status": "invalid", "message": "Invalid verification link. Please check your email."}

            if user.is_email_verified:
                return {"status": "already_verified", "message": "Email is already verified. You can now login."}

            if user.email_verification_expires_at and datetime.utcnow() > user.email_verification_expires_at:
                user.email_verification_token = None
                user.email_verification_expires_at = None
                db.commit()
                return {"status": "expired", "message": "Verification link has expired. Please request a new email."}

            user.is_email_verified = True
            user.status = UserStatus.ACTIVE
            user.email_verification_token = None
            user.email_verification_expires_at = None

            user_tenant = db.query(UserTenant).filter(UserTenant.user_id == user.id).first()

            # Handle platform users who need default tenant with tenant_admin role
            if not user_tenant and user.keycloak_id:
                try:
                    from modules.keycloak_client import KeycloakClient  # type: ignore

                    keycloak_client = KeycloakClient()
                    # Check if this is a platform user
                    user_data = await keycloak_client.get_user_by_id(user.keycloak_id)
                    if user_data and user_data.get("attributes", {}).get("platform_user") == ["true"]:
                        logger.info(f"Creating default tenant for platform user: {email}")

                        # Create default tenant for platform user (no organizations yet)
                        from shared.models import Tenant  # type: ignore

                        # Create tenant with user's name
                        tenant_name = f"{user.first_name} {user.last_name}".strip() or user.email.split('@')[0]
                        tenant = Tenant(
                            name=f"{tenant_name}'s Tenant"
                        )
                        db.add(tenant)
                        db.flush()  # Get the tenant.id

                        # Create UserTenant with tenant_admin role
                        user_tenant = UserTenant(
                            user_id=user.id,
                            tenant_id=tenant.id,
                            app_roles=["tenant_admin"],
                            status=UserStatus.ACTIVE,
                            joined_at=datetime.utcnow()
                        )
                        db.add(user_tenant)

                        logger.info(f"Created default tenant {tenant.id} with tenant_admin role for platform user {email}")

                except ImportError:
                    logger.warning("KeycloakClient not available; cannot check platform user status.")
                except Exception as e:
                    logger.error(f"Failed to create default tenant for platform user {email}: {e}")
                    # Continue with verification even if tenant creation fails

            if user.keycloak_id:
                try:
                    from modules.keycloak_client import KeycloakClient  # type: ignore

                    keycloak_client = KeycloakClient()
                    app_roles = user_tenant.app_roles if (user_tenant and user_tenant.app_roles) else None
                    keycloak_activated = await keycloak_client.activate_user_after_verification(
                        user.keycloak_id, app_roles=app_roles
                    )
                    if not keycloak_activated:
                        logger.warning(f"Failed to activate Keycloak user {user.keycloak_id} for {email}")
                except ImportError:
                    logger.warning("KeycloakClient not available; skipping Keycloak activation step.")

            if user_tenant:
                user_tenant.status = UserStatus.ACTIVE
                user_tenant.joined_at = datetime.utcnow()

                app_access_list = db.query(TenantAppAccess).filter(
                    TenantAppAccess.tenant_id == user_tenant.tenant_id
                ).all()
                for app_access in app_access_list:
                    app_access.current_users += 1

            db.commit()
            logger.info(f"Email verified successfully for user: {email}")

            return {"status": "verified", "message": "Email verified successfully! You can now login."}

        except Exception as exc:  # pragma: no cover - defensive
            logger.error(f"Email verification error: {exc}")
            db.rollback()
            raise Exception(f"Failed to verify email: {exc}") from exc

    async def check_verification_status(self, db: Session, email: str) -> Dict[str, any]:
        """Return the verification status for a user."""
        try:
            user = db.query(User).filter(User.email == email).first()
            if not user:
                return {"status": "user_not_found", "message": "User not found"}

            if user.is_email_verified:
                return {
                    "status": "verified",
                    "message": "Email is verified",
                    "user_status": user.status,
                    "verified_at": user.updated_at.isoformat() if user.updated_at else None,
                }

            if user.email_verification_token:
                is_expired = bool(
                    user.email_verification_expires_at and datetime.utcnow() > user.email_verification_expires_at
                )
                return {
                    "status": "pending",
                    "message": "Email verification pending",
                    "expired": is_expired,
                    "sent_at": user.email_verification_sent_at.isoformat()
                    if user.email_verification_sent_at
                    else None,
                    "expires_at": user.email_verification_expires_at.isoformat()
                    if user.email_verification_expires_at
                    else None,
                }

            return {"status": "not_sent", "message": "Verification email not sent yet"}

        except Exception as exc:  # pragma: no cover - defensive
            logger.error(f"Verification status check error: {exc}")
            raise Exception(f"Failed to check verification status: {exc}") from exc

    def _generate_verification_token(self, email: str) -> str:
        """Generate cryptographically secure verification token."""
        random_bytes = secrets.token_bytes(32)
        timestamp = str(datetime.utcnow().timestamp())
        combined_data = random_bytes + email.encode() + timestamp.encode()
        return hashlib.sha256(combined_data).hexdigest()

    async def _send_verification_email(self, email: str, name: str, token: str):
        """
        Legacy direct SMTP sender. Prefer send_verification_email which uses BaseEmailService.
        Retained for backward compatibility if referenced directly.
        """
        try:
            smtp_host = os.getenv("SMTP_HOST", "smtp.gmail.com")
            smtp_port = int(os.getenv("SMTP_PORT", "587"))
            smtp_user = os.getenv("SMTP_USER")
            smtp_password = os.getenv("SMTP_PASSWORD")
            smtp_use_tls = os.getenv("SMTP_USE_TLS", "true").lower() == "true"
            email_from = os.getenv("EMAIL_FROM", smtp_user)
            email_from_name = os.getenv("EMAIL_FROM_NAME", "SurankuTech")

            if not all([smtp_user, smtp_password, email_from]):
                logger.warning("SMTP configuration incomplete. Auto-verifying for development.")
                logger.info(f"Development verification URL for {email}: {self._build_action_url(email=email, token=token)}")
                await self._auto_verify_development_user(email, token)
                return

            verification_url = self._build_action_url(email=email, token=token)
            subject = "Verify Your Email Address - Suranku Platform"
            html_body = f"""
            <html>
            <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
                <div style="text-align: center; margin-bottom: 30px;">
                    <h1 style="color: #333; margin-bottom: 10px;">Welcome to Suranku Platform!</h1>
                    <p style="color: #666; font-size: 16px;">Please verify your email address to activate your account</p>
                </div>
                <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                    <p>Hi {name},</p>
                    <p>Thank you for creating an account with Suranku Platform. To complete your registration and activate your account, please verify your email address.</p>
                </div>
                <div style="text-align: center; margin: 30px 0;">
                    <a href="{verification_url}"
                       style="background-color: #007bff; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
                        Verify Email Address
                    </a>
                </div>
            </body>
            </html>
            """

            msg = MIMEMultipart("alternative")
            msg["Subject"] = subject
            msg["From"] = f"{email_from_name} <{email_from}>"
            msg["To"] = email
            msg.attach(MIMEText(html_body, "html"))

            with smtplib.SMTP(smtp_host, smtp_port) as server:
                if smtp_use_tls:
                    server.starttls()
                server.login(smtp_user, smtp_password)
                server.send_message(msg)

            logger.info(f"Verification email sent to {email}")

        except Exception as exc:  # pragma: no cover - fallback path
            logger.error(f"Email sending error: {exc}")
            logger.info(f"Development verification URL for {email}: {self._build_action_url(email=email, token=token)}")
            if not os.getenv("SMTP_USER"):
                logger.warning("Email not sent due to missing SMTP configuration")
            else:
                raise Exception(f"Failed to send verification email: {exc}") from exc

    def _build_email_content(self, **kwargs) -> tuple[str, str]:
        """Build the HTML email content."""
        user = kwargs["user"]
        token = kwargs["token"]
        expires_at = kwargs["expires_at"]
        verification_url = self._build_action_url(email=user.email, token=token)
        name = f"{user.first_name} {user.last_name}".strip() or "User"

        subject = "Verify Your Email Address - Suranku Platform"
        html_body = f"""
        <html>
        <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="text-align: center; margin-bottom: 30px;">
                <h1 style="color: #333; margin-bottom: 10px;">Welcome to Suranku Platform!</h1>
                <p style="color: #666; font-size: 16px;">Please verify your email address to activate your account</p>
            </div>
            <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 20px;">
                <p>Hi {name},</p>
                <p>Thank you for creating an account with Suranku Platform. To complete your registration and activate your account, please verify your email address.</p>
            </div>
            <div style="text-align: center; margin: 30px 0;">
                <a href="{verification_url}"
                   style="background-color: #007bff; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; font-weight: bold; display: inline-block;">
                    Verify Email Address
                </a>
            </div>
            <div style="background-color: #fff3cd; border: 1px solid #ffeaa7; padding: 15px; border-radius: 5px; margin: 20px 0;">
                <p style="margin: 0; color: #856404;"><strong>Important:</strong></p>
                <ul style="color: #856404; margin: 10px 0;">
                    <li>This link will expire in 24 hours</li>
                    <li>You cannot login until your email is verified</li>
                    <li>If you didn't create this account, please ignore this email</li>
                </ul>
            </div>
            <div style="margin-top: 30px; padding-top: 20px; border-top: 1px solid #eee; text-align: center;">
                <p style="color: #666; font-size: 14px;">
                    If the button doesn't work, copy and paste this link into your browser:<br>
                    <a href="{verification_url}" style="color: #007bff; word-break: break-all;">{verification_url}</a>
                </p>
                <p style="color: #666; font-size: 12px; margin-top: 20px;">
                    Best regards,<br>
                    Suranku Platform Team
                </p>
            </div>
        </body>
        </html>
        """

        return subject, html_body

    def _build_action_url(self, **kwargs) -> str:
        """Build verification URL using configured APP_BASE_URL."""
        email = kwargs["email"]
        token = kwargs["token"]
        config = self._get_smtp_config()
        return f"{config['app_base_url']}/api/tenants/auth/verify-email?email={email}&token={token}"

    async def cleanup_expired_tokens(self, db: Session) -> int:
        """Remove expired tokens from pending users."""
        try:
            expired_users = db.query(User).filter(
                User.email_verification_expires_at != None,
                User.email_verification_expires_at < datetime.utcnow(),
                User.is_email_verified == False,
            ).all()

            count = 0
            for user in expired_users:
                user.email_verification_token = None
                user.email_verification_expires_at = None
                count += 1

            db.commit()
            logger.info(f"Cleaned up {count} expired verification tokens")
            return count

        except Exception as exc:  # pragma: no cover - defensive
            logger.error(f"Token cleanup error: {exc}")
            db.rollback()
            return 0

    async def _auto_verify_development_user(self, email: str, token: str):
        """Automatically verify a user in development mode when SMTP is not configured."""
        try:
            db = next(get_db())
            try:
                result = await self.verify_email(db, email, token)
                if result["status"] == "verified":
                    logger.info(f"Development mode: Successfully auto-verified user {email}")
                else:
                    logger.warning(f"Development mode: Auto-verification failed for {email}: {result['message']}")
            finally:
                db.close()
        except Exception as exc:  # pragma: no cover - defensive
            logger.error(f"Development auto-verification error for {email}: {exc}")
