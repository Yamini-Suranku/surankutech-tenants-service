from __future__ import annotations

import json
import logging
import os
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

import requests
from fastapi import Depends, HTTPException, Request, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from jose import JWTError, jwt
from sqlalchemy import func, text

logger = logging.getLogger(__name__)

KEYCLOAK_URL = os.getenv("KEYCLOAK_URL") or os.getenv("KEYCLOAK_PUBLIC_URL") or "http://keycloak.shared-services.svc.cluster.local:8080"
REALM = os.getenv("KEYCLOAK_REALM", "suranku-platform")
JWT_SECRET_KEY = os.getenv("JWT_SECRET_KEY", "dev-only-change-me")
JWT_ALGORITHM = os.getenv("JWT_ALGORITHM", "HS256")

security = HTTPBearer()


class TokenData:
    def __init__(self, token_data: Dict[str, Any]):
        self.sub = token_data.get("sub")
        self.user_id = token_data.get("sub")
        self.email = token_data.get("email")
        self.name = token_data.get("name")
        self.preferred_username = token_data.get("preferred_username")

        self.tenant_id = token_data.get("tenant_id")
        self.active_tenant = token_data.get("active_tenant")
        self.all_tenants = token_data.get("all_tenants", [])

        self.resource_access = token_data.get("resource_access", {})
        self.app_roles = token_data.get("app_roles", {})
        self.groups = token_data.get("groups", [])

        self.plan = token_data.get("plan", "free")
        self.trial_expires = token_data.get("trial_expires")

        self.current_org = token_data.get("current_org", {})
        if isinstance(self.current_org, str):
            try:
                parsed_current_org = json.loads(self.current_org)
                self.current_org = parsed_current_org if isinstance(parsed_current_org, dict) else {}
            except json.JSONDecodeError:
                self.current_org = {}

        self.org_memberships = token_data.get("org_memberships", [])
        if isinstance(self.org_memberships, str):
            try:
                parsed_memberships = json.loads(self.org_memberships)
                self.org_memberships = parsed_memberships if isinstance(parsed_memberships, list) else []
            except json.JSONDecodeError:
                self.org_memberships = []

        self.org_app_roles = token_data.get("org_app_roles", {})
        if isinstance(self.org_app_roles, str):
            try:
                parsed_org_roles = json.loads(self.org_app_roles)
                self.org_app_roles = parsed_org_roles if isinstance(parsed_org_roles, dict) else {}
            except json.JSONDecodeError:
                self.org_app_roles = {}

        self.org_id = token_data.get("org_id")
        self.org_slug = token_data.get("org_slug")
        self.org_name = token_data.get("org_name")
        # Populated by get_current_token_data to preserve access to raw bearer token
        # for service-to-service membership resolution fallbacks.
        self.raw_token = token_data.get("raw_token")


async def verify_token(token: str) -> TokenData:
    """Verify JWT token with Keycloak and return normalized token data."""
    try:
        oidc_url = f"{KEYCLOAK_URL}/realms/{REALM}/.well-known/openid-configuration"
        response = requests.get(oidc_url, timeout=10)
        response.raise_for_status()
        jwks_uri = response.json()["jwks_uri"]

        jwks_response = requests.get(jwks_uri, timeout=10)
        jwks_response.raise_for_status()
        jwks = jwks_response.json()

        payload = jwt.decode(
            token,
            jwks,
            algorithms=["RS256"],
            options={"verify_signature": True, "verify_aud": False, "verify_exp": True},
        )
        return TokenData(payload)

    except JWTError as exc:
        logger.error("JWT validation error: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except requests.RequestException as exc:
        logger.error("Keycloak connection error: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Authentication service unavailable",
        )


async def get_current_token_data(credentials: HTTPAuthorizationCredentials = Depends(security)) -> TokenData:
    token_data = await verify_token(credentials.credentials)
    token_data.raw_token = credentials.credentials
    return token_data


async def get_current_user(token_data: TokenData = Depends(get_current_token_data)) -> TokenData:
    return token_data


def create_access_token(
    data: Dict[str, Any],
    expires_delta: Optional[timedelta] = None,
    token_type: str = "access",
) -> str:
    """Create a signed JWT for local/service workflows.

    Note: Keycloak tokens remain the primary auth path; this helper exists for
    compatibility with modules that generate service-local JWTs.
    """
    now = datetime.now(timezone.utc)
    expire = now + (expires_delta or timedelta(minutes=60))
    payload = dict(data)
    payload.update({"type": token_type, "iat": int(now.timestamp()), "exp": int(expire.timestamp())})
    return jwt.encode(payload, JWT_SECRET_KEY, algorithm=JWT_ALGORITHM)


def create_refresh_token(data: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
    return create_access_token(data, expires_delta or timedelta(days=7), token_type="refresh")


def require_tenant_access(token_data: TokenData, tenant_id: str) -> bool:
    if token_data.active_tenant == tenant_id or token_data.tenant_id == tenant_id:
        return True
    return tenant_id in (token_data.all_tenants or []) or tenant_id in (token_data.groups or [])


def extract_subdomain_from_hostname(hostname: str) -> Optional[str]:
    if not hostname:
        return None

    host = hostname.split(":")[0].strip().lower()
    reserved = {"shared", "api", "www", "admin", "status", "platform", "id", "auth", "home", "keycloak"}

    patterns = [
        r"^([a-z0-9\-]+)\.darkhole\.suranku\.(net|com)$",
        r"^([a-z0-9\-]+)\.darkhole\.local\.suranku$",
        r"^([a-z0-9\-]+)\.darkfolio\.suranku\.(net|com)$",
        r"^([a-z0-9\-]+)\.confiploy\.suranku\.(net|com)$",
        r"^([a-z0-9\-]+)\.suranku\.(net|com)$",
        r"^([a-z0-9\-]+)\.local\.suranku$",
    ]

    for pattern in patterns:
        match = re.match(pattern, host)
        if match:
            slug = match.group(1)
            if slug not in reserved:
                return slug
    return None


def get_request_hostname(request: Request) -> str:
    xfh = request.headers.get("x-forwarded-host")
    if xfh:
        return xfh.split(",")[0].strip()
    return request.headers.get("host", "")


def require_app_role(token_data: TokenData, app_client: str, required_role: str) -> bool:
    resource_access = token_data.resource_access or {}

    app_access = resource_access.get(app_client, {})
    if required_role in app_access.get("roles", []):
        return True

    if not app_client.endswith("-client"):
        client_name = f"{app_client}-client"
        client_access = resource_access.get(client_name, {})
        if required_role in client_access.get("roles", []):
            return True

    app_name = app_client[:-7] if app_client.endswith("-client") else app_client
    return required_role in (token_data.app_roles or {}).get(app_name, [])


def _role_from_memberships(token_data: TokenData, org_slug: str, app_client: str, required_role: str) -> Optional[bool]:
    memberships = token_data.org_memberships or []
    if not memberships:
        return None

    normalized_app = app_client[:-7] if app_client.endswith("-client") else app_client
    for membership in memberships:
        candidate_slug = membership.get("org_slug") or membership.get("org_name")
        if candidate_slug == org_slug:
            app_roles = membership.get("app_roles", {})
            roles = app_roles.get(app_client, []) or app_roles.get(normalized_app, [])
            return required_role in roles

    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail=f"Access denied: No membership in organization '{org_slug}'",
    )


def _check_org_membership_and_app_role(token_data: TokenData, org_slug: str, app_client: str, required_role: str) -> bool:
    """DB fallback when token lacks org_memberships."""
    from shared.database import get_db_session

    user_keycloak_id = getattr(token_data, "sub", None)
    if not user_keycloak_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied: Invalid token")

    app_name = app_client[:-7] if app_client.endswith("-client") else app_client

    sql = text(
        """
        SELECT our.roles
          FROM organizations o
          JOIN users u ON u.keycloak_id = :user_keycloak_id
          JOIN organization_user_roles our
            ON our.organization_id = o.id
           AND our.user_id = u.id
           AND our.app_name = :app_name
         WHERE o.slug = :org_slug
           AND o.status = 'active'
           AND o.deleted_at IS NULL
         LIMIT 1
        """
    )

    with get_db_session() as db:
        row = db.execute(
            sql,
            {
                "user_keycloak_id": user_keycloak_id,
                "app_name": app_name,
                "org_slug": org_slug,
            },
        ).first()

    if not row:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Access denied: No access to {app_name} in organization '{org_slug}'",
        )

    roles_value = row[0]
    if isinstance(roles_value, list):
        roles = roles_value
    elif isinstance(roles_value, str):
        try:
            parsed = json.loads(roles_value)
            roles = parsed if isinstance(parsed, list) else [roles_value]
        except json.JSONDecodeError:
            roles = [roles_value]
    else:
        roles = []

    return required_role in roles


def require_org_app_role(token_data: TokenData, hostname: str, app_client: str, required_role: str) -> bool:
    org_slug = extract_subdomain_from_hostname(hostname)
    if not org_slug:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid hostname: No organization subdomain found in '{hostname}'",
        )

    membership_result = _role_from_memberships(token_data, org_slug, app_client, required_role)
    if membership_result is not None:
        return membership_result

    return _check_org_membership_and_app_role(token_data, org_slug, app_client, required_role)


def require_org_admin_access(token_data: TokenData, hostname: str, app_client: str = "darkhole") -> bool:
    return require_org_app_role(token_data, hostname, app_client, "admin")


def require_model_approval_access(token_data: TokenData, app_client: str) -> bool:
    return (
        require_app_role(token_data, app_client, "admin")
        or require_app_role(token_data, app_client, "administrator")
        or require_app_role(token_data, app_client, "evaluator")
        or require_app_role(token_data, app_client, "stuart")
    )


def require_org_model_approval_access(token_data: TokenData, hostname: str, app_client: str = "darkhole") -> bool:
    try:
        return (
            require_org_app_role(token_data, hostname, app_client, "admin")
            or require_org_app_role(token_data, hostname, app_client, "administrator")
            or require_org_app_role(token_data, hostname, app_client, "evaluator")
            or require_org_app_role(token_data, hostname, app_client, "stuart")
        )
    except HTTPException as exc:
        # For control-plane/non-org hosts, preserve old behavior via fallback.
        if exc.status_code == status.HTTP_400_BAD_REQUEST:
            return require_model_approval_access(token_data, app_client)
        raise


def require_darkhole_admin_access(token_data: TokenData, app_client: str = "darkhole") -> bool:
    return require_app_role(token_data, app_client, "admin") or require_app_role(token_data, app_client, "administrator")


def get_user_tenant_id(token_data: TokenData) -> str:
    # Prefer explicit tenant claims when present.
    for candidate in [token_data.active_tenant, token_data.tenant_id]:
        if candidate:
            tenant_value = str(candidate)
            if tenant_value.startswith("tenant"):
                return tenant_value.replace("tenant", "", 1)
            return tenant_value

    # Some flows include tenant information under current_org.
    current_org = token_data.current_org or {}
    if isinstance(current_org, dict):
        for key in ("tenant_id", "active_tenant", "id"):
            value = current_org.get(key)
            if value:
                tenant_value = str(value)
                if tenant_value.startswith("tenant"):
                    return tenant_value.replace("tenant", "", 1)
                return tenant_value

    # Org memberships claim (used by org-scoped SSO flows).
    memberships = token_data.org_memberships or []
    if isinstance(memberships, list):
        for membership in memberships:
            if not isinstance(membership, dict):
                continue
            for key in ("tenant_id", "active_tenant"):
                value = membership.get(key)
                if value:
                    tenant_value = str(value)
                    if tenant_value.startswith("tenant"):
                        return tenant_value.replace("tenant", "", 1)
                    return tenant_value

    # Token may carry all_tenants as a direct list.
    all_tenants = token_data.all_tenants or []
    if isinstance(all_tenants, list) and all_tenants:
        first_tenant = str(all_tenants[0])
        if first_tenant.startswith("tenant"):
            return first_tenant.replace("tenant", "", 1)
        return first_tenant

    groups = token_data.groups or []
    if not groups:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="No tenant access found")

    first_group = str(groups[0])
    if first_group.startswith("tenant"):
        return first_group.replace("tenant", "", 1)
    return first_group


def get_user_tenant_id_from_db(token_data: TokenData, db) -> str:
    from shared.models import User, UserTenant

    user = db.query(User).filter(User.keycloak_id == token_data.sub).first()
    if not user and token_data.email:
        # Fallback for social users where keycloak_id linkage is delayed/missing.
        user = (
            db.query(User)
            .filter(func.lower(User.email) == str(token_data.email).lower())
            .first()
        )
    if not user:
        # Final fallback to signed token tenant hints.
        return get_user_tenant_id(token_data)

    user_tenant = db.query(UserTenant).filter(UserTenant.user_id == user.id).first()
    if not user_tenant:
        # Allow signed token tenant hints if DB mapping is not materialized yet.
        return get_user_tenant_id(token_data)

    return user_tenant.tenant_id


def get_tenant_id_safe(token_data: TokenData, db=None) -> str:
    try:
        return get_user_tenant_id(token_data)
    except HTTPException:
        if db is None:
            raise
        return get_user_tenant_id_from_db(token_data, db)


def check_feature_access(token_data: TokenData, app: str, feature: str) -> bool:
    if token_data.trial_expires and token_data.plan == "trial":
        return True

    feature_matrix = {
        "free": {
            "darkhole": ["admin", "administrator", "consumer"],
            "darkfolio": ["admin", "user"],
            "confiploy": ["admin", "user"],
        },
        "pro": {
            "darkhole": ["admin", "administrator", "model_engineer", "evaluator", "stuart", "consumer"],
            "darkfolio": ["admin", "user", "stuart", "analyst", "reports"],
            "confiploy": ["admin", "user", "devops-engineer", "release-manager", "pipelines"],
        },
        "enterprise": ["all"],
    }

    if token_data.plan == "enterprise":
        return True

    allowed = feature_matrix.get(token_data.plan, {}).get(app, [])
    return feature in allowed


def require_platform_admin_access(token_data: TokenData) -> bool:
    resource_access = token_data.resource_access or {}
    groups = token_data.groups or []

    candidate_clients = ["platform", "platform-client", "realm-management"]
    candidate_roles = {"admin", "platform-admin", "manage-users", "manage-realm"}

    for client in candidate_clients:
        roles = resource_access.get(client, {}).get("roles", [])
        if any(role in candidate_roles for role in roles):
            return True

    return any(
        g == "platform-admin" or g.endswith("/platform-admin") or g.endswith("platform-admin")
        for g in groups
    )
