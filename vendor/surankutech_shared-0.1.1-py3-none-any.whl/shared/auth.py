from jose import JWTError, jwt, jwk
from fastapi import HTTPException, status, Depends, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
import requests
from typing import Optional, Dict, List
import logging
import re

logger = logging.getLogger(__name__)

KEYCLOAK_URL = "http://keycloak.shared-services.svc.cluster.local:8080"
REALM = "suranku-platform"

# Security scheme for JWT tokens
security = HTTPBearer()

class TokenData:
    def __init__(self, token_data: dict):
        self.sub = token_data.get("sub")  # User ID
        self.user_id = token_data.get("sub")  # Alias for user_id
        self.email = token_data.get("email")
        self.name = token_data.get("name")
        self.preferred_username = token_data.get("preferred_username")
        self.tenant_id = token_data.get("tenant_id")  # Current tenant from JWT
        self.active_tenant = token_data.get("active_tenant")
        self.all_tenants = token_data.get("all_tenants", [])
        self.resource_access = token_data.get("resource_access", {})
        self.app_roles = token_data.get("app_roles", {})  # New app_roles format
        self.plan = token_data.get("plan", "free")
        self.trial_expires = token_data.get("trial_expires")
        self.groups = token_data.get("groups", [])

        # Organization-scoped authentication fields
        self.current_org = token_data.get("current_org", {})
        self.org_memberships = token_data.get("org_memberships", [])
        self.org_id = token_data.get("org_id")
        self.org_slug = token_data.get("org_slug")
        self.org_name = token_data.get("org_name")
        self.org_id = token_data.get("org_id")
        self.org_slug = token_data.get("org_slug")
        self.org_name = token_data.get("org_name")

async def verify_token(token: str) -> Optional[TokenData]:
    """Verify JWT token with Keycloak and return user data"""
    try:
        # Debug: Basic token info
        token_parts = token.split('.')
        logger.info(f"🔍 JWT token segments: {len(token_parts)}")
        logger.info(f"📏 Token length: {len(token)} chars")
        logger.info(f"🎯 Token preview: {token[:50]}...{token[-20:] if len(token) > 70 else ''}")

        # Get Keycloak public key
        jwks_url = f"{KEYCLOAK_URL}/realms/{REALM}/.well-known/openid-configuration"
        logger.info(f"Fetching Keycloak config from: {jwks_url}")
        response = requests.get(jwks_url, timeout=10)
        response.raise_for_status()
        jwks_uri = response.json()["jwks_uri"]
        logger.info(f"JWKS URI: {jwks_uri}")

        jwks_response = requests.get(jwks_uri, timeout=10)
        jwks_response.raise_for_status()
        jwks = jwks_response.json()
        logger.info(f"Retrieved {len(jwks.get('keys', []))} keys from JWKS")

        # Decode token
        payload = jwt.decode(
            token,
            jwks,
            algorithms=["RS256"],
            options={"verify_signature": True, "verify_aud": False, "verify_exp": True}
        )

        # Add detailed debugging of the complete token payload
        logger.info(f"🎯 Complete JWT payload: {payload}")
        logger.info(f"🔍 Token claims - sub: {payload.get('sub')}, email: {payload.get('email')}")
        logger.info(f"🔍 Token claims - groups: {payload.get('groups', [])}")
        logger.info(f"🔍 Token claims - tenant_id: {payload.get('tenant_id')}")
        logger.info(f"🔍 Token claims - active_tenant: {payload.get('active_tenant')}")
        logger.info(f"🔍 Token claims - all_tenants: {payload.get('all_tenants', [])}")

        token_data = TokenData(payload)
        logger.info(f"Token verification successful. User: {token_data.email}")
        logger.info(f"📦 TokenData - active_tenant: {token_data.active_tenant}, tenant_id: {token_data.tenant_id}")
        logger.info(f"📦 TokenData - all_tenants: {token_data.all_tenants}, groups: {token_data.groups}")
        logger.info(f"📦 TokenData - app_roles: {token_data.app_roles}")
        logger.info(f"🔍 Raw token resource_access: {payload.get('resource_access', {})}")
        return token_data

    except JWTError as e:
        logger.error(f"JWT validation error: {e}")
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials",
            headers={"WWW-Authenticate": "Bearer"},
        )
    except requests.RequestException as e:
        logger.error(f"Keycloak connection error: {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Authentication service unavailable"
        )

async def get_current_token_data(credentials: HTTPAuthorizationCredentials = Depends(security)) -> TokenData:
    """FastAPI dependency to extract and verify JWT token from Authorization header"""
    try:
        logger.info(f"📥 Received credentials object: {type(credentials)}")
        logger.info(f"📥 Credentials.credentials type: {type(credentials.credentials)}")
        logger.info(f"📥 Token preview: {credentials.credentials[:50] if credentials.credentials else 'NONE'}...")

        token_data = await verify_token(credentials.credentials)
        logger.info(f"🎉 Token verification successful for user: {token_data.email}")
        logger.info(f"🔑 User resource_access: {getattr(token_data, 'resource_access', {})}")
        logger.info(f"🎭 User app_roles: {getattr(token_data, 'app_roles', {})}")
        logger.info(f"👥 User groups: {getattr(token_data, 'groups', [])}")
        return token_data
    except Exception as e:
        logger.error(f"Token verification failed: {e}")
        raise

def require_tenant_access(token_data: TokenData, tenant_id: str) -> bool:
    """Check if user has access to specific tenant"""
    return tenant_id in token_data.all_tenants

# ========== HOSTNAME AND ORGANIZATION UTILITIES ==========

def extract_subdomain_from_hostname(hostname: str) -> Optional[str]:
    """
    Extract organization slug from hostname for DNS-based org resolution.

    Supported patterns:
    - acme.darkhole.suranku.net -> "acme"
    - dnstest.darkhole.suranku.net -> "dnstest"
    - acme.darkhole.local.suranku -> "acme" (development)
    - darkhole.suranku.net -> None (no org subdomain)
    """
    if not hostname:
        return None

    hostname = hostname.split(':')[0].lower()
    patterns = [
        r"^([a-z0-9\-]+)\.darkhole\.suranku\.(net|com)$",
        r"^([a-z0-9\-]+)\.darkhole\.local\.suranku$",
        r"^([a-z0-9\-]+)\.darkfolio\.suranku\.(net|com)$",
        r"^([a-z0-9\-]+)\.confiploy\.suranku\.(net|com)$",
    ]
    for pattern in patterns:
        match = re.match(pattern, hostname)
        if match:
            org_slug = match.group(1)
            if org_slug not in ['shared', 'api', 'www', 'admin', 'status']:
                logger.info(f"📍 Extracted org slug '{org_slug}' from hostname '{hostname}'")
                return org_slug
    logger.debug(f"🔍 No org slug found in hostname '{hostname}'")
    return None

def get_request_hostname(request: Request) -> str:
    hostname = request.headers.get("x-forwarded-host")
    if hostname:
        logger.debug(f"🌐 Using X-Forwarded-Host: {hostname}")
        return hostname.split(',')[0].strip()
    hostname = request.headers.get("host", "")
    logger.debug(f"🌐 Using Host header: {hostname}")
    return hostname

def require_app_role(token_data: TokenData, app_client: str, required_role: str) -> bool:
    """Check if user has specific role in app"""
    logger.info(f"🔍 ROLE CHECK START: app_client={app_client}, required_role={required_role}")
    logger.info(f"👤 User: {getattr(token_data, 'email', 'unknown')}")
    logger.info(f"🔑 Token resource_access: {getattr(token_data, 'resource_access', {})}")
    logger.info(f"🎭 Token app_roles: {getattr(token_data, 'app_roles', {})}")

    # Check resource_access format - try both the exact app_client and with "-client" suffix
    resource_access = getattr(token_data, 'resource_access', {})

    # First try the exact app_client name
    app_access = resource_access.get(app_client, {})
    roles = app_access.get("roles", [])
    logger.info(f"📋 Resource access roles for {app_client}: {roles}")

    if required_role in roles:
        logger.info(f"✅ Found {required_role} in resource_access for {app_client}")
        return True

    # If not found and app_client doesn't end with "-client", try with "-client" suffix
    if not app_client.endswith("-client"):
        client_name = f"{app_client}-client"
        app_access = resource_access.get(client_name, {})
        roles = app_access.get("roles", [])
        logger.info(f"📋 Resource access roles for {client_name}: {roles}")

        if required_role in roles:
            logger.info(f"✅ Found {required_role} in resource_access for {client_name}")
            return True

    # If not found in resource_access, check the app_roles format
    # Map app_client names: "darkhole-client" -> "darkhole", "connectors-client" -> "connectors"
    app_name = app_client.replace("-client", "") if app_client.endswith("-client") else app_client
    app_roles = getattr(token_data, 'app_roles', {}).get(app_name, [])
    logger.info(f"🎯 App roles for {app_name}: {app_roles}")

    result = required_role in app_roles
    logger.info(f"🏁 ROLE CHECK RESULT: {result}")
    if not result:
        logger.warning(f"❌ User {getattr(token_data, 'email', 'unknown')} lacks {required_role} role for {app_client}")
    return result


def require_org_app_role(token_data: TokenData, hostname: str, app_client: str, required_role: str) -> bool:
    """
    Organization-aware role check. Requires an org slug in the hostname; otherwise raises 400.
    Falls back to DB lookup if org memberships are missing in the token.
    """
    logger.info(f"🔐 ORG ROLE CHECK: hostname={hostname}, app={app_client}, role={required_role}")
    logger.info(f"👤 User: {getattr(token_data, 'email', 'unknown')}")

    org_slug = extract_subdomain_from_hostname(hostname)
    if not org_slug:
        logger.error(f"❌ No valid organization subdomain in hostname '{hostname}'")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid hostname: No organization subdomain found in '{hostname}'"
        )

    logger.info(f"🏢 Target organization: {org_slug}")

    org_memberships = getattr(token_data, 'org_memberships', [])
    if org_memberships:
        logger.info(f"📋 User org memberships: {[m.get('org_slug') for m in org_memberships]}")
        for org_membership in org_memberships:
            if org_membership.get('org_slug') == org_slug:
                org_app_roles = org_membership.get('app_roles', {}).get(app_client, [])
                logger.info(f"🎯 User roles in {org_slug}.{app_client}: {org_app_roles}")
                if required_role in org_app_roles:
                    logger.info(f"✅ Access granted: {required_role} found in org-specific roles")
                    return True
                logger.warning(f"❌ Access denied: {required_role} not in org-specific roles {org_app_roles}")
                return False
        logger.warning(f"❌ Access denied: User not member of organization '{org_slug}'")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Access denied: No membership in organization '{org_slug}'"
        )

    # No org memberships in token; fallback to DB validation
    logger.info("🔄 No org_memberships in token, checking database for org access")
    return _check_org_membership_and_app_role(token_data, org_slug, app_client, required_role)


def _check_org_membership_and_app_role(token_data: TokenData, org_slug: str, app_client: str, required_role: str) -> bool:
    """
    DB fallback: ensure the user belongs to org_slug and has required_role for the app in org context.
    """
    from shared.models import Organization, OrganizationUserRole, User
    from shared.database import get_db_session

    logger.info(f"🔐 ORG + APP ROLE CHECK: org={org_slug}, app={app_client}, role={required_role}")

    user_id = getattr(token_data, 'sub', None)
    if not user_id:
        logger.error("❌ No user ID in token")
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied: Invalid token")

    try:
        with get_db_session() as db:
            org = db.query(Organization).filter(
                Organization.slug == org_slug,
                Organization.status == "active"
            ).first()
            if not org:
                logger.warning(f"❌ Organization '{org_slug}' not found or inactive")
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=f"Access denied: Organization '{org_slug}' not accessible")

            user = db.query(User).filter(User.keycloak_id == user_id).first()
            if not user:
                logger.warning(f"❌ User {user_id} not found in system")
                raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Access denied: User not found")

            org_user_role = db.query(OrganizationUserRole).filter(
                OrganizationUserRole.organization_id == org.id,
                OrganizationUserRole.user_id == user.id,
                OrganizationUserRole.app_name == app_client.replace("-client", "")
            ).first()

            if not org_user_role:
                logger.warning(f"❌ User {user_id} has no roles in org '{org_slug}' for app '{app_client}'")
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail=f"Access denied: No access to {app_client} in organization '{org_slug}'"
                )

            user_roles = org_user_role.roles or []
            if required_role not in user_roles:
                logger.warning(f"❌ User {user_id} lacks '{required_role}' role for {app_client} in '{org_slug}'. Has: {user_roles}")
                return False

            logger.info(f"✅ User {user_id} has '{required_role}' role for {app_client} in org '{org_slug}'")
            return True

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"❌ Database error during org validation: {e}")
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Unable to validate organization access")

def get_user_tenant_id(token_data: TokenData) -> str:
    """Extract tenant ID from token groups"""
    if not token_data.groups:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tenant access found"
        )

    # Groups format: ["tenant123"]
    tenant_group = token_data.groups[0]
    if not tenant_group.startswith("tenant"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid tenant group format"
        )

    return tenant_group.replace("tenant", "")

def get_user_tenant_id_from_db(token_data: TokenData, db) -> str:
    """Get tenant ID from database using user's ID - fallback when groups aren't available"""
    from shared.models import User, UserTenant

    # Get user from database
    user = db.query(User).filter(User.keycloak_id == token_data.sub).first()
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="User not found"
        )

    # Get user's tenant relationship
    user_tenant = db.query(UserTenant).filter(UserTenant.user_id == user.id).first()
    if not user_tenant:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tenant access found for user"
        )

    return user_tenant.tenant_id

def get_tenant_id_safe(token_data: TokenData, db=None) -> str:
    """Safely get tenant ID - try groups first, fallback to database if available"""
    try:
        # Try to get from groups first (preferred method)
        return get_user_tenant_id(token_data)
    except HTTPException:
        # If groups not available and database provided, try database lookup
        if db is not None:
            return get_user_tenant_id_from_db(token_data, db)
        # If no database available, re-raise the original exception
        raise

def check_feature_access(token_data: TokenData, app: str, feature: str) -> bool:
    """Check if user has access to specific feature based on plan"""
    # During trial, all features are available
    if token_data.trial_expires and token_data.plan == "trial":
        return True

    # Feature access based on plan
    feature_matrix = {
        "free": {
            "darkhole": ["admin", "administrator", "consumer"],
            "darkfolio": ["admin", "user"],
            "confiploy": ["admin", "user"]
        },
        "pro": {
            "darkhole": ["admin", "administrator", "model_engineer", "evaluator", "stuart", "consumer"],
            "darkfolio": ["admin", "user", "stuart", "analyst", "reports"],
            "confiploy": ["admin", "user", "devops-engineer", "release-manager", "pipelines"]
        },
        "enterprise": ["all"]  # All features
    }

    if token_data.plan == "enterprise":
        return True

    allowed_features = feature_matrix.get(token_data.plan, {}).get(app, [])
    return feature in allowed_features

def require_darkhole_admin_access(token_data: TokenData, app_client: str = "darkhole") -> bool:
    """Check if user has DarkHole admin access (legacy admin or new administrator roles)"""
    return (require_app_role(token_data, app_client, "admin") or
            require_app_role(token_data, app_client, "administrator"))

def require_model_approval_access(token_data: TokenData, app_client: str) -> bool:
    """Check if user has model approval access (admin, administrator, evaluator, or stuart roles)"""
    return (require_app_role(token_data, app_client, "admin") or
            require_app_role(token_data, app_client, "administrator") or
            require_app_role(token_data, app_client, "evaluator") or
            require_app_role(token_data, app_client, "stuart"))

async def get_current_user(token_data: TokenData = Depends(get_current_token_data)):
    """Get current user information from token data"""
    return token_data

# Organization-scoped authentication functions
import re

def extract_subdomain_from_hostname(hostname: str) -> Optional[str]:
    """Extract organization subdomain from hostname patterns"""
    if not hostname:
        return None

    patterns = [
        r"^([a-z0-9\-]+)\.darkhole\.suranku\.(net|com)$",
        r"^([a-z0-9\-]+)\.darkhole\.local\.suranku$",
        r"^([a-z0-9\-]+)\.darkfolio\.suranku\.(net|com)$",
        r"^([a-z0-9\-]+)\.confiploy\.suranku\.(net|com)$",
    ]

    for pattern in patterns:
        match = re.match(pattern, hostname.lower())
        if match:
            return match.group(1)

    return None

def get_request_hostname(request) -> str:
    """Extract hostname from FastAPI request object"""
    # Check X-Forwarded-Host header first (for proxied requests)
    hostname = request.headers.get("x-forwarded-host")
    if hostname:
        logger.debug(f"🌐 Using X-Forwarded-Host: {hostname}")
        return hostname.split(',')[0].strip()  # Take first if multiple

    # Fallback to Host header
    hostname = request.headers.get("host", "")
    logger.debug(f"🌐 Using Host header: {hostname}")
    return hostname

def require_org_app_role(token_data: TokenData, hostname: str, app_client: str, required_role: str) -> bool:
    """
    Check if user has specific role in app for the organization determined by hostname.

    This function provides proper organization-level isolation to prevent cross-org access vulnerabilities.

    Args:
        token_data: Validated JWT token data
        hostname: Request hostname (e.g., "acme.darkhole.suranku.net")
        app_client: App client name (e.g., "darkhole", "darkfolio")
        required_role: Required role (e.g., "admin", "consumer")

    Returns:
        True if user has the required role for this org's app, False otherwise

    Raises:
        HTTPException: If user has no access to the organization or hostname is invalid
    """
    logger.info(f"🔐 ORG ROLE CHECK: hostname={hostname}, app={app_client}, role={required_role}")
    logger.info(f"👤 User: {getattr(token_data, 'email', 'unknown')}")

    # Extract organization slug from hostname
    org_slug = extract_subdomain_from_hostname(hostname)
    if not org_slug:
        logger.error(f"❌ No valid organization subdomain in hostname '{hostname}'")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid hostname: No organization subdomain found in '{hostname}'"
        )

    logger.info(f"🏢 Target organization: {org_slug}")

    # Check org memberships in token
    org_memberships = getattr(token_data, 'org_memberships', [])
    if org_memberships:
        logger.info(f"📋 User org memberships: {[m.get('org_slug') for m in org_memberships]}")

        # Find matching organization membership
        for org_membership in org_memberships:
            if org_membership.get('org_slug') == org_slug:
                org_app_roles = org_membership.get('app_roles', {}).get(app_client, [])
                logger.info(f"🎯 User roles in {org_slug}.{app_client}: {org_app_roles}")

                if required_role in org_app_roles:
                    logger.info(f"✅ Access granted: {required_role} found in org-specific roles")
                    return True
                else:
                    logger.warning(f"❌ Access denied: {required_role} not in org-specific roles {org_app_roles}")
                    return False

        logger.warning(f"❌ Access denied: User not member of organization '{org_slug}'")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Access denied: No membership in organization '{org_slug}'"
        )

    # Fallback to basic role check if no org memberships in token
    logger.info(f"🔄 No org_memberships in token, falling back to basic app role check")
    return require_app_role(token_data, app_client, required_role)

def require_org_admin_access(token_data: TokenData, hostname: str, app_client: str = "darkhole") -> bool:
    """Check if user has organization admin access for the specific org"""
    return require_org_app_role(token_data, hostname, app_client, "admin")

def require_org_model_approval_access(token_data: TokenData, hostname: str, app_client: str = "darkhole") -> bool:
    """Check if user has model approval access in the specific organization"""
    # Try org-scoped roles first
    try:
        return (require_org_app_role(token_data, hostname, app_client, "admin") or
                require_org_app_role(token_data, hostname, app_client, "administrator") or
                require_org_app_role(token_data, hostname, app_client, "evaluator") or
                require_org_app_role(token_data, hostname, app_client, "stuart"))
    except HTTPException:
        # If hostname-based org check fails, fallback to legacy check
        return require_model_approval_access(token_data, app_client)


def require_platform_admin_access(token_data: TokenData) -> bool:
    """
    Determine if the caller has platform-level admin powers.

    Checks resource_access roles for common platform admin indicators and
    also allows a group named (or suffixed with) platform-admin.
    """
    resource_access = getattr(token_data, "resource_access", {}) or {}
    groups = getattr(token_data, "groups", []) or []

    candidate_clients = ["platform", "platform-client", "realm-management"]
    candidate_roles = {"admin", "platform-admin", "manage-users", "manage-realm"}

    for client in candidate_clients:
        roles = resource_access.get(client, {}).get("roles", [])
        if any(role in candidate_roles for role in roles):
            logger.info(f"✅ Platform admin via client={client}, roles={roles}")
            return True

    if any(
        g == "platform-admin"
        or g.endswith("/platform-admin")
        or g.endswith("platform-admin")
        for g in groups
    ):
        logger.info(f"✅ Platform admin via group membership: {groups}")
        return True

    logger.warning("❌ Platform admin access not detected on token")
    return False
