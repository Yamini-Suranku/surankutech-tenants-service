from sqlalchemy import Column, String, DateTime, JSON, Boolean, Integer
from datetime import datetime
import uuid

from .database import Base


class Connector(Base):
    """External service connector configuration"""
    __tablename__ = "connectors"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    tenant_id = Column(String, nullable=False, index=True)

    # Connector details
    name = Column(String, nullable=False)
    type = Column(String, nullable=False)  # jira, github, tableau, postgres
    description = Column(String)

    # Configuration (non-sensitive data only)
    config = Column(JSON, default=dict)

    # Security
    vault_path = Column(String)  # Path to secrets in Vault

    # Status
    status = Column(String, default="inactive")  # inactive, active, error, disabled
    last_test = Column(DateTime)
    last_sync = Column(DateTime)
    error_message = Column(String)

    # Sync settings
    sync_enabled = Column(Boolean, default=True)
    sync_interval_minutes = Column(Integer, default=60)  # Default hourly sync

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class ConnectorCredential(Base):
    """Connector authentication credentials (references to Vault)"""
    __tablename__ = "connector_credentials"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    connector_id = Column(String, nullable=False, index=True)
    tenant_id = Column(String, nullable=False, index=True)

    # Credential metadata
    credential_type = Column(String, nullable=False)  # api_key, oauth2, basic_auth
    vault_path = Column(String, nullable=False)
    description = Column(String)

    # OAuth specific fields
    oauth_token_expires_at = Column(DateTime)
    oauth_refresh_token_path = Column(String)  # Separate vault path for refresh token

    # Status
    is_active = Column(Boolean, default=True)
    last_verified = Column(DateTime)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class SyncJob(Base):
    """Data synchronization job tracking"""
    __tablename__ = "sync_jobs"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    connector_id = Column(String, nullable=False, index=True)
    tenant_id = Column(String, nullable=False, index=True)

    # Job details
    job_type = Column(String, default="full_sync")  # full_sync, incremental_sync, test_sync
    status = Column(String, default="pending")  # pending, running, completed, failed, canceled

    # Execution details
    started_at = Column(DateTime)
    completed_at = Column(DateTime)
    duration_seconds = Column(Integer)

    # Results
    records_processed = Column(Integer, default=0)
    records_created = Column(Integer, default=0)
    records_updated = Column(Integer, default=0)
    records_failed = Column(Integer, default=0)

    # Error handling
    error_message = Column(String)
    error_details = Column(JSON)
    retry_count = Column(Integer, default=0)
    max_retries = Column(Integer, default=3)

    # Sync metadata
    sync_params = Column(JSON, default=dict)  # Custom parameters for this sync
    last_sync_cursor = Column(String)  # For incremental syncs

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class SyncedData(Base):
    """Cached synchronized data from external services"""
    __tablename__ = "synced_data"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    connector_id = Column(String, nullable=False, index=True)
    tenant_id = Column(String, nullable=False, index=True)
    sync_job_id = Column(String, nullable=False, index=True)

    # External record details
    external_id = Column(String, nullable=False, index=True)
    external_type = Column(String, nullable=False)  # issue, repository, workbook, table
    external_url = Column(String)

    # Data payload
    data = Column(JSON, nullable=False)
    meta_data = Column(JSON, default=dict)

    # Processing status
    processing_status = Column(String, default="pending")  # pending, processed, failed
    processed_at = Column(DateTime)

    # Data freshness
    external_updated_at = Column(DateTime)
    last_synced_at = Column(DateTime, default=datetime.utcnow)

    # Search fields (for faster queries)
    search_text = Column(String)  # Concatenated searchable text
    tags = Column(JSON, default=list)  # Searchable tags

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class ConnectorWebhook(Base):
    """Webhook endpoints for real-time data updates"""
    __tablename__ = "connector_webhooks"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    connector_id = Column(String, nullable=False, index=True)
    tenant_id = Column(String, nullable=False, index=True)

    # Webhook details
    webhook_url = Column(String, nullable=False)  # External service webhook URL
    webhook_secret = Column(String)  # Secret for webhook verification
    event_types = Column(JSON, default=list)  # Types of events to listen for

    # Status
    is_active = Column(Boolean, default=True)
    last_ping = Column(DateTime)
    success_count = Column(Integer, default=0)
    failure_count = Column(Integer, default=0)

    # Configuration
    retry_failed_events = Column(Boolean, default=True)
    max_retry_attempts = Column(Integer, default=3)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class ConnectorMapping(Base):
    """Field mappings between external services and internal schema"""
    __tablename__ = "connector_mappings"

    id = Column(String, primary_key=True, default=lambda: str(uuid.uuid4()))
    connector_id = Column(String, nullable=False, index=True)
    tenant_id = Column(String, nullable=False, index=True)

    # Mapping configuration
    source_type = Column(String, nullable=False)  # External data type (e.g., 'jira_issue')
    target_schema = Column(String, nullable=False)  # Internal schema name
    field_mappings = Column(JSON, nullable=False)  # Field mapping rules

    # Transformation rules
    transformation_rules = Column(JSON, default=list)
    validation_rules = Column(JSON, default=list)

    # Status
    is_active = Column(Boolean, default=True)
    version = Column(Integer, default=1)

    # Timestamps
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
